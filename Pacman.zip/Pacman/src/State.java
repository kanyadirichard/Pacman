
// A szellemek �llapot lehet Scatter - ekkor kimennek a saj�t sarkukba vagy Chase - ekkor �ld�zik Pacmant
public enum State {
	Scatter,
	Chase
}
