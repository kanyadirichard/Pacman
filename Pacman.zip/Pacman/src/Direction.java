// Az entit�sokhoz tartoz� ir�nyok
public enum Direction {
	Up, 
	Right, 
	Down,
	Left
}
